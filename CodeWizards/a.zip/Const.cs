﻿namespace Com.CodeGame.CodeWizards2016.DevKit.CSharpCgdk
{
    public class Const
    {
        public static double Width, Height;
        public static double Eps = 1e-9;
    }
}
