﻿namespace Com.CodeGame.CodeWizards2016.DevKit.CSharpCgdk
{
    public class Const
    {
        public static double MapSize;
        public static double Eps = 1e-9;
        public static double TreeMaxRadius = 50;
    }
}
