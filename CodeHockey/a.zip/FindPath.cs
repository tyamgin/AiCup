﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using System.Xml.XPath;
using Com.CodeGame.CodeHockey2014.DevKit.CSharpCgdk.Model;
using Point = Com.CodeGame.CodeTroopers2013.DevKit.CSharpCgdk.Point;

namespace Com.CodeGame.CodeHockey2014.DevKit.CSharpCgdk
{
    public partial class MyStrategy : IStrategy
    {
        public bool FindPath(Hockeyist self, Point to, Point lookAt, Point goalie)
        {
            var okDist = HoRadius * 1.5;

            var minTime = Inf;
            var selTurn = 0.0;
            var selSpUp = 0.0;
            for (var dir = -1; dir <= 1; dir += 2)
            {
                var hock = new AHock(self);
                for (var ticksDirect = 0; ticksDirect < 100; ticksDirect++)
                {
                    var curTime = ticksDirect;
                    var ho = hock.Clone();
                    while (Math.Abs(ho.GetAngleTo(lookAt)) > Deg(8))
                    {
                        ho.Move(0, TurnNorm(ho.GetAngleTo(lookAt), ho.Base.Agility));
                        curTime++;
                    }
                    if (curTime < minTime && ho.GetDistanceTo(to) < okDist)
                    {
                        minTime = curTime;
                        if (ticksDirect == 0)
                        {
                            selSpUp = 0.0;
                            selTurn = TurnNorm(ho.GetAngleTo(lookAt), self.Agility);
                        }
                        else if (dir > 0)
                        {
                            selTurn = self.GetAngleTo(to.X, to.Y);
                            selSpUp = GetSpeedTo(selTurn);
                        }
                        else
                        {
                            selTurn = RevAngle(self.GetAngleTo(to.X, to.Y));
                            selSpUp = -GetSpeedTo(selTurn);
                        }
                    }
                    if (dir > 0)
                        GetTicksToUpN(hock, to, 0, 1);
                    else
                        GetTicksToDownN(hock, to, 0, 1);
                }
            }
            move.SpeedUp = selSpUp;
            move.Turn = selTurn;
            return minTime != Inf;
        }
    }
}
