﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Com.CodeGame.CodeHockey2014.DevKit.CSharpCgdk.Model;

namespace Com.CodeGame.CodeHockey2014.DevKit.CSharpCgdk
{
    public class Global
    {
        public static Game game;
        public static Double FrictionPuckCoeff;
        public static Double FrictionHockCoeff;
        public static double HoRadius;
        public static double PuckRadius;
        public static Player my, opp;
    }
}
